import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import dev.mfazio.rock_paper_scissors_application.R

class MainActivity : AppCompatActivity(), LocationListener {
    private lateinit var locationManager: LocationManager
    private lateinit var tvGpsLocation: TextView
    private val locationPermissionCode = 2
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "KotlinApp"
        val button: Button = findViewById(R.id.getLocation)
        button.setOnClickListener {
            getLocation()
        }
    }
    private fun getLocation() {
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if ((ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), locationPermissionCode)
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5f, this)
    }
    override fun onLocationChanged(location: Location) {
        tvGpsLocation = findViewById(R.id.textView)
        tvGpsLocation.text = "Latitude: " + location.latitude + " , Longitude: " + location.longitude
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationPermissionCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show()
            }
            else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
            }
        }
    }
    Button b_rock, b_scissors, b_paper;
    TextView tv_score;
    ImageView iv_ComputerChoice, iv_humanChoice;
    int HumanScore, ComputerScore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b_paper = (Button) findViewById(R.id.b_paper);
        b_scissors = (Button) findViewById(R.id.b_scissors);
        b_rock = (Button) findViewById(R.id.b_rock);

        iv_ComputerChoice = (ImageView) findViewById(R.id.iv_ComputerChoice);
        iv_humanChoice = (ImageView) findViewById(R.id.iv_humanChoice);

        tv_score = (TextView) findViewById(R.id.tv_score);

        b_paper.setOnContextClickListener(new View.OnContextClickListener() {
            @Override
            public boolean onContextClick(View v) {
                iv_humanChoice.setImageResource(R.drawable.ic_baseline_pan_tool_24);
                String message = play_turn("paper");
                Toast.makeText(MainActivity.this,message, Toast.LENGTH_SHORT).show();
                return false;
            }
        });

        b_rock.setOnContextClickListener(new View.OnContextClickListener() {
            @Override
            public boolean onContextClick(View v) {
                iv_humanChoice.setImageResource(R.drawable.ic_baseline_thumb_up_24);
                String message = play_turn("rock");
                Toast.makeText(MainActivity.this,message, Toast.LENGTH_SHORT).show();
                return false;
            }
        });

        b_scissors.setOnContextClickListener(new View.OnContextClickListener() {
            @Override
            public boolean onContextClick(View v) {
                iv_humanChoice.setImageResource(R.drawable.ic_baseline_architecture_24);
                String message = play_turn("scissors");
                Toast.makeText(MainActivity.this,message, Toast.LENGTH_SHORT).show();
                return false;
            }
        });
    }

    public String play_turn(String Player_Choice) {

        String computer_Choice = "";
        Random r = new Random();
        int computer_choice_number = r.nextInt(3) + 1;

        if (computer_choice_number == 1) {
            computer_Choice = " rock ";
        }
        if (computer_choice_number == 2) {
            computer_Choice = " scissors ";
        }
        if (computer_choice_number == 3) {
            computer_Choice = " paper ";
        }

        if (computer_Choice == "rock") {
            iv_ComputerChoice.setImageResource(R.drawable.ic_baseline_thumb_up_24);
        } else ;
        if (computer_Choice == "scissors") {
            iv_ComputerChoice.setImageResource(R.drawable.ic_baseline_architecture_24);
        } else ;
        if (computer_Choice == "paper") {
            iv_ComputerChoice.setImageResource(R.drawable.ic_baseline_pan_tool_24);
        } else ;

        if (computer_Choice == Player_Choice) {
            return "Draw, Nobody Won";
        } else if (Player_Choice == "rock" && computer_Choice == "scissors") {
            HumanScore++;
            return "Rock crushes scissors. You Win";
        } else if (Player_Choice == "rock" && computer_Choice == "paper") {
            ComputerScore++;
            return "Paper Covers rock. Computer Wins";
        } else if (Player_Choice == "scissors" && computer_Choice == "rock") {
            ComputerScore++;
            return "Rock Crushes Scissors. Computer Wins";
        } else if (Player_Choice == "scissors" && computer_Choice == "paper") {
            HumanScore++;
            return "Scissors cuts paper. You Win";
        } else if (Player_Choice == "paper" && computer_Choice == "rock") {
            HumanScore++;
            return "Paper Covers rock. You Win";
        }else if (Player_Choice == "paper" && computer_Choice == "scissors") {
            ComputerScore++;
            return "Scissors cuts paper. Computer Wins";
        }
        else return"Who won?";


    }
}

